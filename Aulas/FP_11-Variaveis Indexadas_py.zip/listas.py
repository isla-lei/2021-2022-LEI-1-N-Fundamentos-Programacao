lista1 = [10, 20, 30, 40, 50, 60]

#print(lista1)

###################################################
# uma lista tratada como um array 
lista_numeros =[0]*6 # define uma lista com 6 celulas com o valor 0
print(lista_numeros)

lista_numeros[0] = 10
lista_numeros[1] = 20
lista_numeros[2] = 30
lista_numeros[3] = 40
lista_numeros[4] = 50
lista_numeros[5] = 60

print(lista_numeros)
##########################


celulas = int(input("Quantidade de celulas: "))
lista_dados = [0]*celulas
print(lista_dados)


##########################

tam = 5
lista_numeros = [0]*tam # define uma lista com 10 celulas com o valor zero
print(lista_numeros)

for i in range(tam):
    lista_numeros[i] = int(input(str(i+1) + "º Número: "))

print(lista_numeros)

##########################
print("AQUI")
tam = 5
lista_numeros = []
for i in range(tam):
    numero = int(input(str(i+1) + "º Número: "))
    lista_numeros.append(numero)

print(lista_numeros)

lista_notas = []

contador = 1
while True:
        print("Registo nº " + str(contador))

        nota = float(input(" Nota...............: "))
        
        if nota < 0:
            break

        lista_notas.append(nota)

        contador = contador + 1


print (lista_notas)

# loop atraves dos elementos
for elemento in lista_notas:
    print(elemento)

# loop atraves do indice
for i in range(len(lista_notas)):
    print(lista_notas[i])
