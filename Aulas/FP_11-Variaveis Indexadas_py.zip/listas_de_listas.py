produto1 = [ "maçã", 10, 0.30]
produto2 = [ "pera", 5, 0.75]
produto3 = [ "kiwi", 4, 0.98]

compras = [ produto1, produto2, produto3]
print(compras)


lista_notas = []
while True:
    numero = int(input("Numero: "))

    if numero == 0:
        break

    nome = input("Nome: ")
    nota = float(input("Nota:"))

    registo = [numero, nome, nota]
    print(registo)

    lista_notas.append(registo)
    print(lista_notas)



for elemento in lista_notas:
    #print(elemento)
    print(f"Numero.: {elemento[0]}")
    print(f"Nome...: {elemento[1]}")
    print(f"Nota...: {elemento[2]}")


# guardar
#arquivo=open("dados.txt","w")
#for elemento in lista_notas:
#    arquivo.write(f"{elemento[0]}, {elemento[1]}, {elemento[2]}\n")

#arquivo.close()  

# ler ficheiro
arquivo=open("dados.txt","r")
for linha in arquivo.readlines():
    print(linha)
arquivo.close()  

