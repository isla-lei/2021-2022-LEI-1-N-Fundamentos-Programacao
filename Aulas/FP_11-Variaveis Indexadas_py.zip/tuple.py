tupla = (1, 3, 7, 8, 7, 5, 4, 6, 8, 5)

conta = tupla.count(5)

print(conta)


pos = tupla.index(8)

print(pos)
