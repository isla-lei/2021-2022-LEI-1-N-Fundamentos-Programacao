fruits = ['apple', 'banana', 'cherry']
print(fruits)

##

fruits.append("orange")
print(fruits)
##

fruits.clear()
print(fruits)

###
fruits = ['apple', 'banana', 'cherry']
fruits.append("orange")

nova_lista = fruits.copy()

print(nova_lista)

###
conta = fruits.count("cherry")

print(conta)

###
fruits = ['apple', 'banana', 'cherry']
cars = ['Ford', 'BMW', 'Volvo']

fruits.extend(cars)
print(fruits)

###
fruits = ['apple', 'banana', 'cherry']

pos = fruits.index("cherry")
print(pos)


###

fruits = ['apple', 'banana', 'cherry']
fruits.insert(1, "orange")

print(fruits)

###
fruits = ['apple', 'banana', 'cherry']

fruits.pop(1)
print(fruits)

###
fruits = ['apple', 'banana', 'cherry']

fruits.remove("banana")

print(fruits)

###
fruits = ['apple', 'banana', 'cherry']

fruits.reverse()

print(fruits)

###
cars = ['Ford', 'BMW', 'Volvo']

cars.sort()

print(cars)



