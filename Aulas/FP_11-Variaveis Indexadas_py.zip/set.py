conjunto1 = {'um', 'dois', 'tres'}
conjunto2 = {'um', 'dois', 'tres', ('a', 'b')}

# mostra conjuntos
print(conjunto1)
print(conjunto2)

# Não podemos aceder aos elementos pelo seu indice
# print(conjunto1[2])

# iteração por todos os valores
for item in conjunto1:
    print(item)

for item in conjunto2:
    print(item)

