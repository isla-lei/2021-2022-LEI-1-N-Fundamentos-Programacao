

ficheiro = open("dados.txt","w")

ficheiro.write("Valor a escrever no ficheiro")

ficheiro.close()

#
ficheiro = open("dados.txt","w")

for linha in range(1,101):
    ficheiro.write(f"{linha}\n")

ficheiro.close()

#
ficheiro=open("dados.txt","r")
for linha in ficheiro.readlines():
    print(linha)

ficheiro.close()

