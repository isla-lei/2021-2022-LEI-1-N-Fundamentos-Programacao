
#import io
#f = io.open("test.txt", mode="r", encoding="utf-8")


produto1 = [ "laranja", 10, 0.99]
produto2 = [ "pera", 5, 0.75]
produto3 = [ "kiwi", 4, 0.98]

lista_compras = [ produto1, produto2, produto3]

print(lista_compras)

ficheiro = open("compras.txt","w")
ficheiro.write("produto; quantidade; preco\n")
for elemento in lista_compras:
    ficheiro.writelines(f"{elemento[0]}; {elemento[1]}; {elemento[2]}\n")

ficheiro.close()


print("*"*100)
# ler dados do ficheiro
ficheiro = open("compras.txt","r")
contador = 1
lista_compras = []
for linha in ficheiro.readlines():    
    #print(linha)
    if (contador > 1): # ignorar a 1ª linha
        # reconstruir lista    
        campos = linha.split(";") # separa a linha pelo separador ";" e coloca na lista campos
        #print(campos)        
        produto = [campos[0], campos[1], campos[2].rstrip("\n")] # retira "\n" do campo
        #print(campos)
        #print(produto)
        lista_compras.append(produto)
    
    contador = contador + 1

print(lista_compras)

ficheiro.close()

